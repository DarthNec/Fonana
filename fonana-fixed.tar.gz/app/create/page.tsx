'use client'

import { ContentCreator } from '../../components/ContentCreator'
import { 
  PhotoIcon, 
  FilmIcon, 
  DocumentTextIcon, 
  SparklesIcon,
  LightBulbIcon,
  CurrencyDollarIcon,
  RocketLaunchIcon,
  BeakerIcon,
  BoltIcon
} from '@heroicons/react/24/outline'

const contentTypes = [
  {
    type: 'image',
    name: 'Image',
    description: 'Photos, art, screenshots and other images',
    icon: PhotoIcon,
    gradient: 'from-blue-500 to-cyan-500',
    shadowColor: 'shadow-blue-500/25'
  },
  {
    type: 'video',
    name: 'Video',
    description: 'Video clips, streams, tutorials',
    icon: FilmIcon,
    gradient: 'from-purple-500 to-pink-500',
    shadowColor: 'shadow-purple-500/25'
  },
  {
    type: 'text',
    name: 'Text',
    description: 'Articles, posts, stories',
    icon: DocumentTextIcon,
    gradient: 'from-green-500 to-emerald-500',
    shadowColor: 'shadow-green-500/25'
  },
  {
    type: 'nft',
    name: 'NFT',
    description: 'Unique digital assets',
    icon: SparklesIcon,
    gradient: 'from-yellow-500 to-orange-500',
    shadowColor: 'shadow-yellow-500/25'
  }
]

const tips = [
  {
    title: 'Quality content',
    description: 'Create unique and interesting content for your audience',
    icon: LightBulbIcon,
    gradient: 'from-purple-500 to-pink-500'
  },
  {
    title: 'Fair pricing',
    description: 'Set fair prices considering the value of your content',
    icon: CurrencyDollarIcon,
    gradient: 'from-green-500 to-emerald-500'
  },
  {
    title: 'Consistency',
    description: 'Publish content regularly to maintain audience interest',
    icon: RocketLaunchIcon,
    gradient: 'from-blue-500 to-cyan-500'
  }
]

export default function CreatePage() {
  return (
    <div className="min-h-screen bg-slate-900">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full">
          <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-2/3 right-1/4 w-80 h-80 bg-pink-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
        <div className="absolute top-40 right-20 w-3 h-3 bg-pink-400 rounded-full animate-pulse"></div>
        <div className="absolute bottom-40 left-20 w-1 h-1 bg-blue-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-20 right-10 w-2 h-2 bg-green-400 rounded-full animate-bounce delay-700"></div>
      </div>

      <div className="relative z-10">
        <div className="container mx-auto px-4 pt-32 pb-8 lg:pt-40 lg:pb-12">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <div className="mb-8">
              <h1 className="text-5xl lg:text-7xl font-bold mb-6">
                <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent animate-pulse">
                  Create content
                </span>
              </h1>
              <p className="text-xl lg:text-2xl text-slate-300 max-w-4xl mx-auto leading-relaxed">
                Share your creativity with the world and earn cryptocurrency for your work
              </p>
            </div>
            
            {/* Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-6 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/25">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <BeakerIcon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">50K+</h3>
                <p className="text-slate-400">Content created</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-6 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/25">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <BoltIcon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">2.5%</h3>
                <p className="text-slate-400">Platform commission</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-6 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/25">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <CurrencyDollarIcon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">100%</h3>
                <p className="text-slate-400">Your rights</p>
              </div>
            </div>
          </div>

          {/* Content Types Overview */}
          <div className="mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-center mb-4">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Content types
              </span>
            </h2>
            <p className="text-xl text-slate-400 text-center mb-12 max-w-2xl mx-auto">
              Choose the appropriate format for your creativity
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {contentTypes.map((type) => (
                <div 
                  key={type.type}
                  className="group bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-8 text-center hover:scale-105 transition-all duration-500 hover:shadow-2xl hover:border-slate-600/50"
                  style={{
                    boxShadow: `0 25px 50px -12px ${type.shadowColor}`
                  }}
                >
                  <div className={`w-20 h-20 bg-gradient-to-r ${type.gradient} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <type.icon className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-purple-400 group-hover:to-pink-400 group-hover:bg-clip-text transition-all duration-300">
                    {type.name}
                  </h3>
                  <p className="text-slate-400 leading-relaxed">
                    {type.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Main Content Creator */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-8 lg:p-12 mb-16 hover:shadow-2xl hover:shadow-purple-500/10 transition-all duration-500">
            <h2 className="text-3xl font-bold mb-2">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Upload new content
              </span>
            </h2>
            <p className="text-slate-400 mb-8 text-lg">Create and publish your unique content</p>
            <ContentCreator />
          </div>

          {/* Tips Section */}
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-3xl p-8 lg:p-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Content creation tips
                </span>
              </h2>
              <p className="text-xl text-slate-400 max-w-2xl mx-auto">
                Useful recommendations for successful creation
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              {tips.map((tip, index) => (
                <div key={index} className="group text-center hover:scale-105 transition-all duration-300">
                  <div className={`w-16 h-16 bg-gradient-to-r ${tip.gradient} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <tip.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-purple-400 group-hover:to-pink-400 group-hover:bg-clip-text transition-all duration-300">
                    {tip.title}
                  </h3>
                  <p className="text-slate-400 leading-relaxed">
                    {tip.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Additional Tips */}
            <div className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 backdrop-blur-sm border border-purple-500/30 rounded-2xl p-8">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">💡</span>
                </div>
                <div>
                  <h4 className="text-2xl font-bold text-white mb-2">
                    Useful information
                  </h4>
                  <p className="text-slate-300">Important details for successful publication</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-slate-300">
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"></div>
                    <span>File size limited to 100MB for images</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-300">
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"></div>
                    <span>500MB for video content</span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-slate-300">
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"></div>
                    <span>NFT content automatically minted on Solana</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-300">
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"></div>
                    <span>You retain all copyrights</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 