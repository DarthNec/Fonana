'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { 
  HeartIcon, 
  ChatBubbleLeftIcon, 
  ShareIcon, 
  LockClosedIcon,
  PlayIcon,
  CheckBadgeIcon,
  EyeIcon,
  PaperAirplaneIcon,
  ChevronDownIcon,
  ChevronUpIcon
} from '@heroicons/react/24/outline'
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid'

interface Creator {
  id: number
  name: string
  username: string
  avatar: string
  isVerified: boolean
}

interface Comment {
  id: number
  user: {
    name: string
    username: string
    avatar: string
    isVerified: boolean
  }
  content: string
  createdAt: string
  likes: number
  isLiked?: boolean
  replies?: Comment[]
}

interface PostCardProps {
  id: number
  creator: Creator
  title: string
  content: string
  image?: string
  type: 'text' | 'image' | 'video' | 'audio'
  isLocked: boolean
  price?: number
  currency?: string
  likes: number
  comments: number
  createdAt: string
  tags: string[]
  isPremium?: boolean
  isSubscribed?: boolean
  showCreator?: boolean
}

// Mock comments data
const mockComments: Comment[] = [
  {
    id: 1,
    user: {
      name: 'Alex Blockchain',
      username: 'alexblockchain',
      avatar: '/avatars/alex.jpg',
      isVerified: false
    },
    content: 'Выглядит потрясающе! Когда будет минт?',
    createdAt: '2024-01-15T11:00:00Z',
    likes: 5,
    replies: [
      {
        id: 11,
        user: {
          name: 'Anna Crypto',
          username: 'annacrypto',
          avatar: '/avatars/anna.jpg',
          isVerified: true
        },
        content: 'Спасибо! Планируем запуск на следующей неделе 🚀',
        createdAt: '2024-01-15T11:05:00Z',
        likes: 8
      }
    ]
  },
  {
    id: 2,
    user: {
      name: 'Crypto Marina',
      username: 'cryptomarina',
      avatar: '/avatars/marina.jpg',
      isVerified: true
    },
    content: 'Анна, твои работы всегда на высшем уровне! Обязательно буду участвовать в минте 🚀',
    createdAt: '2024-01-15T11:15:00Z',
    likes: 12
  }
]

export default function PostCard({
  id,
  creator,
  title,
  content,
  image,
  type,
  isLocked,
  price,
  currency,
  likes,
  comments,
  createdAt,
  tags,
  isPremium = false,
  isSubscribed = false,
  showCreator = true
}: PostCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(likes)
  const [showComments, setShowComments] = useState(false)
  const [commentsData, setCommentsData] = useState<Comment[]>(mockComments)
  const [newComment, setNewComment] = useState('')
  const [replyTo, setReplyTo] = useState<number | null>(null)
  const [replyContent, setReplyContent] = useState('')

  const handleLike = () => {
    setIsLiked(!isLiked)
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1)
  }

  const handleCommentLike = (commentId: number) => {
    setCommentsData(prev => prev.map(comment => 
      comment.id === commentId 
        ? { 
            ...comment, 
            likes: comment.likes + (comment.isLiked ? -1 : 1), 
            isLiked: !comment.isLiked 
          }
        : comment
    ))
  }

  const handleReplyLike = (commentId: number, replyId: number) => {
    setCommentsData(prev => prev.map(comment => 
      comment.id === commentId 
        ? {
            ...comment,
            replies: comment.replies?.map(reply =>
              reply.id === replyId
                ? {
                    ...reply,
                    likes: reply.likes + (reply.isLiked ? -1 : 1),
                    isLiked: !reply.isLiked
                  }
                : reply
            ) || []
          }
        : comment
    ))
  }

  const handleAddComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: Date.now(),
        user: {
          name: 'You',
          username: 'you',
          avatar: '/avatars/default.jpg',
          isVerified: false
        },
        content: newComment,
        createdAt: new Date().toISOString(),
        likes: 0
      }
      setCommentsData([...commentsData, comment])
      setNewComment('')
    }
  }

  const handleAddReply = (commentId: number) => {
    if (replyContent.trim()) {
      const reply: Comment = {
        id: Date.now(),
        user: {
          name: 'You',
          username: 'you',
          avatar: '/avatars/default.jpg',
          isVerified: false
        },
        content: replyContent,
        createdAt: new Date().toISOString(),
        likes: 0
      }
      
      setCommentsData(prev => prev.map(comment => 
        comment.id === commentId 
          ? { ...comment, replies: [...(comment.replies || []), reply] }
          : comment
      ))
      setReplyContent('')
      setReplyTo(null)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const canViewContent = !isLocked || isSubscribed
  const needsPayment = isLocked && !isSubscribed && price

  return (
    <article className="group relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-800/40 to-slate-900/60 backdrop-blur-xl border border-slate-700/50 hover:border-purple-500/30 transition-all duration-500 mb-8">
      {/* Hover glow effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-purple-600/10 to-pink-600/10 rounded-3xl opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500"></div>
      
      <div className="relative z-10">
        {/* Creator Info Header */}
        {showCreator && (
          <div className="flex items-center gap-3 p-6 pb-4">
            <Link href={`/creator/${creator.id}`} className="flex items-center gap-3 group/creator">
              <div className="relative w-12 h-12 rounded-2xl overflow-hidden border border-purple-500/30 bg-gradient-to-br from-purple-500/20 to-pink-500/20">
                <Image
                  src={creator.avatar}
                  alt={creator.name}
                  width={48}
                  height={48}
                  className="object-cover"
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-white group-hover/creator:text-purple-300 transition-colors">
                    {creator.name}
                  </h3>
                  {creator.isVerified && (
                    <CheckBadgeIcon className="w-4 h-4 text-blue-400" />
                  )}
                </div>
                <p className="text-slate-400 text-sm">@{creator.username}</p>
              </div>
            </Link>
            
            <div className="ml-auto text-slate-400 text-sm">
              {formatDate(createdAt)}
            </div>
          </div>
        )}

        {/* Content */}
        <div className={`px-6 ${!showCreator ? 'pt-6' : ''}`}>
          {/* Title */}
          <h2 className="text-xl font-bold text-white mb-3 leading-tight">
            {title}
          </h2>

          {/* Content Preview */}
          <div className="mb-4">
            {canViewContent ? (
              <p className="text-slate-300 leading-relaxed line-clamp-3">
                {content}
              </p>
            ) : (
              <div className="relative bg-gradient-to-r from-slate-800/30 to-slate-700/30 rounded-xl p-4 border border-slate-600/30">
                <p className="text-slate-400 leading-relaxed line-clamp-2 opacity-40">
                  {content}
                </p>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-slate-800/90 backdrop-blur-sm rounded-xl px-4 py-2 flex items-center gap-2 text-slate-300 text-sm border border-slate-600/50">
                    <LockClosedIcon className="w-4 h-4" />
                    {needsPayment ? `${price} ${currency}` : 'Только для подписчиков'}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Media Content */}
          {image && (
            <div className="relative mb-4 rounded-2xl overflow-hidden bg-gradient-to-br from-purple-900/10 to-pink-900/10">
              {canViewContent ? (
                <>
                  <Image
                    src={image}
                    alt={title}
                    width={500}
                    height={300}
                    className="w-full h-64 object-cover"
                  />
                  {type === 'video' && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 bg-black/50 backdrop-blur-sm rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                        <PlayIcon className="w-8 h-8 text-white ml-1" />
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="w-full h-64 bg-gradient-to-br from-slate-700/20 to-slate-800/40 flex items-center justify-center relative">
                  <div className="text-center">
                    <LockClosedIcon className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                    <div className="text-slate-400 font-medium mb-2">
                      {needsPayment ? 'Paid Content' : 'Premium Content'}
                    </div>
                    {needsPayment && (
                      <div className="text-purple-400 font-bold text-lg">
                        {price} {currency}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Premium Badge */}
          {isPremium && (
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-300 text-sm font-medium rounded-full border border-purple-500/30 mb-4">
              <span className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></span>
              Premium Content
            </div>
          )}

          {/* Tags */}
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 bg-slate-700/50 text-slate-400 text-sm rounded-full hover:bg-slate-600/50 transition-colors"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between p-6 pt-4 border-t border-slate-700/50">
          <div className="flex items-center gap-6">
            {/* Like */}
            <button
              onClick={handleLike}
              className="flex items-center gap-2 text-slate-400 hover:text-red-400 transition-colors group/like"
            >
              {isLiked ? (
                <HeartSolidIcon className="w-5 h-5 text-red-500" />
              ) : (
                <HeartIcon className="w-5 h-5 group-hover/like:scale-110 transition-transform" />
              )}
              <span className="font-medium">{likeCount}</span>
            </button>

            {/* Comments */}
            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center gap-2 text-slate-400 hover:text-blue-400 transition-colors group/comment"
            >
              <ChatBubbleLeftIcon className="w-5 h-5 group-hover/comment:scale-110 transition-transform" />
              <span className="font-medium">{commentsData.length}</span>
              {showComments ? (
                <ChevronUpIcon className="w-4 h-4" />
              ) : (
                <ChevronDownIcon className="w-4 h-4" />
              )}
            </button>

            {/* Views */}
            <div className="flex items-center gap-2 text-slate-400">
              <EyeIcon className="w-5 h-5" />
              <span className="font-medium">{Math.floor(likes * 4.2)}</span>
            </div>
          </div>

          {/* Share */}
          <button className="flex items-center gap-2 text-slate-400 hover:text-purple-400 transition-colors group/share">
            <ShareIcon className="w-5 h-5 group-hover/share:scale-110 transition-transform" />
          </button>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="border-t border-slate-700/50 bg-slate-800/20 backdrop-blur-sm">
            {/* Add Comment */}
            <div className="p-6 border-b border-slate-700/30">
              <div className="flex gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-sm">Me</span>
                </div>
                <div className="flex-1">
                  <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Write a comment..."
                    className="w-full px-4 py-3 bg-slate-700/50 border border-slate-600/50 rounded-xl text-white placeholder-slate-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 resize-none text-sm"
                    rows={2}
                  />
                  <div className="flex justify-end mt-3">
                    <button
                      onClick={handleAddComment}
                      disabled={!newComment.trim()}
                      className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-slate-600 disabled:to-slate-600 text-white font-medium px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 text-sm hover:scale-105 disabled:hover:scale-100"
                    >
                      <PaperAirplaneIcon className="w-4 h-4" />
                      Send
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Comments List */}
            <div className="max-h-96 overflow-y-auto">
              {commentsData.map((comment) => (
                <div key={comment.id} className="p-4 border-b border-slate-700/20 last:border-b-0">
                  <div className="flex gap-3">
                                      <div className="relative w-10 h-10 rounded-xl overflow-hidden border border-purple-500/20 bg-gradient-to-br from-purple-500/10 to-pink-500/10 flex-shrink-0">
                    {comment.user.avatar ? (
                      <Image
                        src={comment.user.avatar}
                        alt={comment.user.name}
                        width={40}
                        height={40}
                        className="object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none'
                          e.currentTarget.nextElementSibling?.classList.remove('hidden')
                        }}
                      />
                    ) : null}
                    <div className={`absolute inset-0 flex items-center justify-center text-white font-bold text-sm ${comment.user.avatar ? 'hidden' : ''}`}>
                      {comment.user.name.charAt(0).toUpperCase()}
                    </div>
                  </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium text-white text-sm">{comment.user.name}</h4>
                        {comment.user.isVerified && (
                          <CheckBadgeIcon className="w-3 h-3 text-blue-400" />
                        )}
                        <span className="text-slate-400 text-xs">@{comment.user.username}</span>
                        <span className="text-slate-500 text-xs">•</span>
                        <span className="text-slate-500 text-xs">{formatDate(comment.createdAt)}</span>
                      </div>
                      <p className="text-slate-300 text-sm leading-relaxed mb-2">{comment.content}</p>
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => handleCommentLike(comment.id)}
                          className="flex items-center gap-1 text-slate-400 hover:text-red-400 transition-colors group text-xs"
                        >
                          {comment.isLiked ? (
                            <HeartSolidIcon className="w-3 h-3 text-red-500" />
                          ) : (
                            <HeartIcon className="w-3 h-3 group-hover:scale-110 transition-transform" />
                          )}
                          <span>{comment.likes}</span>
                        </button>
                        <button 
                          onClick={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                          className="text-slate-400 hover:text-purple-400 transition-colors text-xs"
                        >
                          Reply
                        </button>
                      </div>

                      {/* Reply Form */}
                      {replyTo === comment.id && (
                        <div className="mt-3 flex gap-2">
                          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center flex-shrink-0">
                            <span className="text-white font-bold text-xs">Me</span>
                          </div>
                          <div className="flex-1">
                            <textarea
                              value={replyContent}
                              onChange={(e) => setReplyContent(e.target.value)}
                              placeholder="Write a reply..."
                              className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600/50 rounded-lg text-white placeholder-slate-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 resize-none text-xs"
                              rows={2}
                            />
                            <div className="flex justify-end gap-2 mt-2">
                              <button
                                onClick={() => setReplyTo(null)}
                                className="text-slate-400 hover:text-white text-xs px-3 py-1 rounded transition-colors"
                              >
                                Cancel
                              </button>
                              <button
                                onClick={() => handleAddReply(comment.id)}
                                disabled={!replyContent.trim()}
                                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-slate-600 disabled:to-slate-600 text-white font-medium px-3 py-1 rounded transition-all duration-300 text-xs"
                              >
                                Reply
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Replies */}
                      {comment.replies && comment.replies.length > 0 && (
                        <div className="mt-3 space-y-3">
                          {comment.replies.map((reply) => (
                            <div key={reply.id} className="flex gap-2 pl-4 border-l-2 border-slate-700/50">
                                                          <div className="relative w-8 h-8 rounded-lg overflow-hidden border border-purple-500/20 bg-gradient-to-br from-purple-500/10 to-pink-500/10 flex-shrink-0">
                              {reply.user.avatar ? (
                                <Image
                                  src={reply.user.avatar}
                                  alt={reply.user.name}
                                  width={32}
                                  height={32}
                                  className="object-cover"
                                  onError={(e) => {
                                    e.currentTarget.style.display = 'none'
                                    e.currentTarget.nextElementSibling?.classList.remove('hidden')
                                  }}
                                />
                              ) : null}
                              <div className={`absolute inset-0 flex items-center justify-center text-white font-bold text-xs ${reply.user.avatar ? 'hidden' : ''}`}>
                                {reply.user.name.charAt(0).toUpperCase()}
                              </div>
                            </div>
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <h5 className="font-medium text-white text-xs">{reply.user.name}</h5>
                                  {reply.user.isVerified && (
                                    <CheckBadgeIcon className="w-3 h-3 text-blue-400" />
                                  )}
                                  <span className="text-slate-400 text-xs">@{reply.user.username}</span>
                                  <span className="text-slate-500 text-xs">•</span>
                                  <span className="text-slate-500 text-xs">{formatDate(reply.createdAt)}</span>
                                </div>
                                <p className="text-slate-300 text-xs leading-relaxed mb-1">{reply.content}</p>
                                <button 
                                  onClick={() => handleReplyLike(comment.id, reply.id)}
                                  className="flex items-center gap-1 text-slate-400 hover:text-red-400 transition-colors group text-xs"
                                >
                                  {reply.isLiked ? (
                                    <HeartSolidIcon className="w-3 h-3 text-red-500" />
                                  ) : (
                                    <HeartIcon className="w-3 h-3 group-hover:scale-110 transition-transform" />
                                  )}
                                  <span>{reply.likes}</span>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Unlock Button */}
        {!canViewContent && (
          <div className="p-6 pt-0">
            <Link
              href={needsPayment ? `/post/${id}/purchase` : `/creator/${creator.id}/subscribe`}
              className="w-full group/unlock block"
            >
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-2xl font-semibold text-center transform group-hover/unlock:scale-105 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/25">
                {needsPayment ? `Purchase for ${price} ${currency}` : 'Subscribe for access'}
              </div>
            </Link>
          </div>
        )}
      </div>
    </article>
  )
} 