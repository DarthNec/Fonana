# 🍌 Fonana - Web3 Creator Platform

> Революционная децентрализованная платформа для авторов, объединяющая лучшие функции Ko-fi и OnlyFans на базе Web3 технологий.

[![Next.js](https://img.shields.io/badge/Next.js-14-black)](https://nextjs.org/)
[![Solana](https://img.shields.io/badge/Solana-Web3-purple)](https://solana.com/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)](https://www.typescriptlang.org/)
[![Tailwind](https://img.shields.io/badge/Tailwind-CSS-cyan)](https://tailwindcss.com/)

## 🌟 Особенности

### 👨‍🎨 Для Авторов
- **🔗 Интеграция кошельков**: Phantom, MetaMask, WalletConnect
- **📝 Создание контента**: Загрузка изображений, видео, текста
- **💎 NFT подписки**: Эксклюзивные NFT пропуски с уровнями доступа
- **💰 Система донатов**: Получение чаевых с персональными сообщениями
- **📊 Аналитика**: Отслеживание доходов, подписчиков, активности
- **⚙️ Гибкие настройки**: Настройка цен, уровней доступа, комиссий

### 🎯 Для Подписчиков
- **🔐 Мульти-кошелёк**: Поддержка Solana и Ethereum кошельков
- **💳 Гибкие платежи**: SOL, USDC, ETH
- **🎨 NFT коллекция**: Торгуемые подписочные NFT
- **🔓 Автоматический доступ**: Верификация через владение кошельком
- **💬 Социальные функции**: Комментарии и взаимодействие

### 💸 Система Платежей
- **⚡ Solana Pay**: Быстрые, дешёвые транзакции
- **🔗 Ethereum**: Полная Web3 совместимость
- **📈 Комиссии платформы**:
  - Подписки: 10%
  - Донаты: 2.5%
  - Разовые покупки: 15%
- **👑 Роялти**: 5% с продаж NFT на вторичном рынке

## 🏗 Архитектура

```
Frontend (Next.js) → Web3 Integration → Payment System → NFT System
       ↓                    ↓               ↓            ↓
   Dashboard           Wallet Adapters   Solana Pay   Metaplex NFTs
   Content Creator     Multi-chain       Ethereum     Access Control
   Subscription UI     Support           Transfers    Content Gating
```

## 🛠 Технологический Стек

### Frontend
- **Next.js 14** - React фреймворк с App Router
- **TypeScript** - Типизированный JavaScript
- **Tailwind CSS** - Utility-first CSS фреймворк
- **Heroicons** - Иконки для UI

### Web3 Integration
- **@solana/web3.js** - Solana blockchain интеграция
- **@solana/wallet-adapter** - Solana кошельки
- **@solana/spl-token** - SPL токены (USDC)
- **@metaplex-foundation/mpl-token-metadata** - NFT метаданные
- **wagmi** - Ethereum React hooks
- **ethers.js** - Ethereum библиотека

### Платежи и NFT
- **Solana Pay** - Мгновенные криптоплатежи
- **Metaplex** - NFT стандарт Solana
- **Token Metadata Program** - NFT метаданные
- **Associated Token Accounts** - Токен аккаунты

## 📦 Установка и Запуск

```bash
# Клонирование репозитория
git clone https://github.com/yourusername/fonana.git
cd fonana

# Установка зависимостей
npm install

# Настройка переменных окружения
cp env.example .env.local

# Запуск dev сервера
npm run dev
```

## 🔧 Переменные Окружения

```env
# Solana Configuration
NEXT_PUBLIC_SOLANA_RPC_HOST=https://api.devnet.solana.com

# Ethereum Configuration  
NEXT_PUBLIC_ETHEREUM_RPC_URL=your_ethereum_rpc_url

# WalletConnect
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=your_walletconnect_project_id

# Platform Configuration
NEXT_PUBLIC_PLATFORM_FEE_WALLET=your_platform_wallet_address
```

## 🎮 Использование

### Подключение Кошелька
1. Нажмите "Connect Wallet" в шапке сайта
2. Выберите ваш кошелёк (Phantom, MetaMask, etc.)
3. Подтвердите подключение

### Создание Контента
1. Перейдите на страницу "Создать"
2. Выберите тип контента (изображение, видео, текст, NFT)
3. Установите уровень доступа и цену
4. Опубликуйте контент

### Покупка NFT Подписки
1. Выберите автора
2. Выберите уровень подписки (Silver, Gold, Platinum)
3. Подтвердите транзакцию в кошельке
4. Получите NFT пропуск

## 🎯 Дорожная Карта

### ✅ Фаза 1 - MVP (Завершено)
- Базовый UI/UX дизайн
- Интеграция кошельков Solana/Ethereum
- Система реальных криптоплатежей
- NFT подписки с Metaplex
- Создание и управление контентом
- Отображение балансов кошелька

### 🚧 Фаза 2 - Backend & Storage (В разработке)
- [ ] Supabase backend API
- [ ] IPFS/Arweave хранилище файлов
- [ ] Anchor смарт-контракты
- [ ] Система уведомлений
- [ ] Продвинутая аналитика

### 🔮 Фаза 3 - Advanced Features (Планируется)
- [ ] DAO управление платформой
- [ ] Кросс-чейн поддержка (Polygon, BSC)
- [ ] Мобильное приложение
- [ ] Telegram/Discord боты
- [ ] Реферальная программа
- [ ] Стейкинг токенов платформы

## 💰 Экономическая Модель

### Комиссии Платформы
| Тип операции | Комиссия | Получатель |
|-------------|----------|------------|
| Подписки | 10% | Платформа |
| Донаты | 2.5% | Платформа |
| Покупки контента | 15% | Платформа |
| NFT роялти | 5% | Автор |

### NFT Подписки
| Уровень | Цена | Длительность | Особенности |
|---------|------|-------------|-------------|
| Silver | $5 USDC | 1 месяц | Базовый доступ |
| Gold | $12 USDC | 3 месяца | Премиум + DM |
| Platinum | $40 USDC | 12 месяцев | Всё + DAO + NFT |

## 🔐 Безопасность

- **Децентрализация**: Нет единой точки отказа
- **Кошелёк как аутентификация**: Криптографическая безопасность
- **Смарт-контракты**: Автоматическое исполнение условий
- **NFT верификация**: Неподдельные права доступа

## 🤝 Вклад в Проект

Мы приветствуем вклад сообщества! 

### Как помочь:
1. 🐛 Сообщайте о багах через Issues
2. 💡 Предлагайте новые функции
3. 🔧 Отправляйте Pull Requests
4. 📖 Улучшайте документацию
5. 🎨 Предлагайте UI/UX улучшения

### Процесс разработки:
```bash
# Форк репозитория
git fork https://github.com/yourusername/fonana.git

# Создание ветки для фичи
git checkout -b feature/amazing-feature

# Коммит изменений
git commit -m 'Add amazing feature'

# Пуш в ветку
git push origin feature/amazing-feature

# Создание Pull Request
```

## 📊 Статистика Проекта

- **Поддерживаемые блокчейны**: Solana, Ethereum
- **Типы кошельков**: 8+ (Phantom, MetaMask, WalletConnect, etc.)
- **Валюты**: SOL, USDC, ETH
- **Типы контента**: Изображения, видео, текст, NFT
- **Уровни доступа**: Публичный, подписчики, премиум

## 🔗 Полезные Ссылки

- 🌐 [Официальный сайт](https://fonana.app) (в разработке)
- 📚 [Документация](https://docs.fonana.app) (в разработке)
- 💬 [Discord сообщество](https://discord.gg/fonana) (в разработке)
- 🐦 [Twitter](https://twitter.com/fonana_app) (в разработке)
- 📱 [Telegram](https://t.me/fonana_platform) (в разработке)

## 📄 Лицензия

Этот проект лицензирован под MIT License - см. файл [LICENSE](LICENSE) для деталей.

## 🙏 Благодарности

- **Solana Foundation** - за потрясающий блокчейн
- **Metaplex** - за NFT инфраструктуру
- **Next.js Team** - за отличный фреймворк
- **Tailwind CSS** - за удобные стили
- **Сообщество Web3** - за поддержку и вдохновение

---

<div align="center">

**Сделано с ❤️ для Web3 сообщества**

[⭐ Поставьте звезду](https://github.com/yourusername/fonana) • [🐛 Сообщить о баге](https://github.com/yourusername/fonana/issues) • [💡 Предложить фичу](https://github.com/yourusername/fonana/discussions)

</div> 