import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { WalletProvider } from '../components/WalletProvider'
import { ClientOnly } from '../components/ClientOnly'
import { Navbar } from '../components/Navbar'
import { UserProvider } from '../components/UserProvider'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Fonana - Web3 Creator Platform',
  description: 'Decentralized creator platform with crypto payments and NFT subscriptions',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ClientOnly>
          <WalletProvider>
            <UserProvider>
              <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
                <Navbar />
                <main className="pt-0">
                  {children}
                </main>
              </div>
            </UserProvider>
          </WalletProvider>
        </ClientOnly>
      </body>
    </html>
  )
} 