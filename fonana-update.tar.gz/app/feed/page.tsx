'use client'

import { useState } from 'react'
import { postsData, getCreatorById } from '@/lib/mockData'
import PostCard from '@/components/PostCard'
import { SparklesIcon, FireIcon, RocketLaunchIcon } from '@heroicons/react/24/solid'
import { FunnelIcon } from '@heroicons/react/24/outline'

export default function FeedPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All')
  
  // Sort posts by date (newest first)
  const sortedPosts = [...postsData].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )
  
  // Get unique categories from posts
  const categories = ['All', ...Array.from(new Set(
    sortedPosts.map(post => {
      const creator = getCreatorById(post.creatorId)
      return creator?.category || 'Other'
    })
  ))]
  
  // Filter posts by category
  const filteredPosts = selectedCategory === 'All' 
    ? sortedPosts 
    : sortedPosts.filter(post => {
        const creator = getCreatorById(post.creatorId)
        return creator?.category === selectedCategory
      })

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800">
      {/* Hero Header Section */}
      <div className="relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-32 h-32 bg-purple-500 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-40 right-32 w-24 h-24 bg-pink-500 rounded-full blur-2xl animate-pulse" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-20 left-1/3 w-28 h-28 bg-blue-500 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="relative z-10 container mx-auto px-6 lg:px-8 py-16 lg:py-24">
          <div className="text-center max-w-4xl mx-auto">
            {/* Main Title */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl flex items-center justify-center border border-purple-500/30">
                <SparklesIcon className="w-6 h-6 text-purple-400" />
              </div>
              <h1 className="text-5xl lg:text-6xl font-black text-white">
                Creator <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Feed</span>
              </h1>
              <div className="w-12 h-12 bg-gradient-to-br from-pink-500/20 to-purple-500/20 rounded-2xl flex items-center justify-center border border-pink-500/30">
                <RocketLaunchIcon className="w-6 h-6 text-pink-400" />
              </div>
            </div>
            
            <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
              Discover the best content from talented creators in the Web3 space
            </p>

            {/* Stats Bar */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
              <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 text-center">
                <div className="text-3xl font-bold text-purple-400 mb-2">1,247</div>
                <span>active posts</span>
              </div>
              <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 text-center">
                <div className="text-3xl font-bold text-pink-400 mb-2">12</div>
                <span>categories</span>
              </div>
              <div className="bg-slate-800/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-6 text-center">
                <div className="text-3xl font-bold text-blue-400 mb-2">24/7</div>
                <span>updates</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="container mx-auto px-6 lg:px-8 pb-16">
        {/* Category Filter */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center gap-3">
              <FunnelIcon className="w-6 h-6 text-purple-400" />
              <h2 className="text-2xl font-bold text-white">Filters</h2>
            </div>
            <div className="flex-1 h-px bg-gradient-to-r from-purple-500/30 to-transparent"></div>
          </div>
          
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-2xl text-sm font-semibold transition-all duration-300 transform hover:scale-105 ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25'
                    : 'bg-slate-800/50 text-slate-300 hover:bg-slate-700/50 hover:text-white border border-slate-700/50 hover:border-purple-500/30 backdrop-blur-sm'
                }`}
              >
                {category === 'All' ? 'All categories' : category}
              </button>
            ))}
          </div>
        </div>

        {/* Posts Count */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-800/40 backdrop-blur-sm rounded-2xl border border-slate-700/50">
            <span className="text-slate-400">Showing:</span>
            <span className="font-bold text-white">{filteredPosts.length}</span>
            <span className="text-slate-400">
              {filteredPosts.length === 1 ? 'post' : 'posts'}
              {selectedCategory !== 'All' && (
                <span className="ml-2 px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-xs">
                  {selectedCategory}
                </span>
              )}
            </span>
          </div>
        </div>

        {/* Posts Feed */}
        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            {filteredPosts.map((post) => {
              const creator = getCreatorById(post.creatorId)
              if (!creator) return null

              return (
                <PostCard
                  key={post.id}
                  id={post.id}
                  creator={{
                    id: creator.id,
                    name: creator.name,
                    username: creator.username,
                    avatar: creator.avatar,
                    isVerified: creator.isVerified
                  }}
                  title={post.title}
                  content={post.content}
                  image={post.thumbnail}
                  type={post.type}
                  isLocked={post.isLocked}
                  price={post.price}
                  currency={post.currency}
                  likes={post.likes}
                  comments={post.comments}
                  createdAt={post.createdAt}
                  tags={post.tags}
                  isPremium={post.isLocked && (post.price || 0) > 0.05}
                  isSubscribed={false} // В фиде по умолчанию не подписан
                  showCreator={true}
                />
              )
            })}
          </div>
        </div>

        {/* Empty State */}
        {filteredPosts.length === 0 && (
          <div className="text-center py-16">
            <div className="max-w-md mx-auto">
              <div className="w-24 h-24 mx-auto mb-8 bg-gradient-to-br from-slate-700/20 to-slate-800/40 rounded-3xl flex items-center justify-center border border-slate-600/30">
                <SparklesIcon className="w-12 h-12 text-slate-500" />
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-4">
                No posts found
              </h3>
              
              <p className="text-slate-400 mb-8 leading-relaxed">
                There are no posts in the "{selectedCategory}" category. Try selecting another category or view all content.
              </p>
              
              <button
                onClick={() => setSelectedCategory('All')}
                className="group"
              >
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-2xl font-bold transform group-hover:scale-105 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/25">
                  Show all posts
                </div>
              </button>
            </div>
          </div>
        )}

        {/* Load More CTA */}
        {filteredPosts.length > 0 && (
          <div className="text-center mt-16">
            <div className="max-w-md mx-auto">
              <div className="relative group overflow-hidden rounded-3xl">
                {/* Gradient background */}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 via-pink-600/20 to-purple-600/20 opacity-50"></div>
                <div className="absolute inset-0 bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm"></div>
                
                {/* Floating elements */}
                <div className="absolute top-4 right-4 w-16 h-16 bg-purple-500/10 rounded-full blur-xl"></div>
                <div className="absolute bottom-4 left-4 w-12 h-12 bg-pink-500/10 rounded-full blur-xl"></div>
                
                <div className="relative z-10 p-8 text-center">
                  <h3 className="text-xl font-bold text-white mb-3">
                    Want more content?
                  </h3>
                  
                  <p className="text-slate-300 mb-6">
                    Subscribe to your favorite creators and get exclusive content first
                  </p>
                  
                  <button className="group/btn">
                    <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-2xl font-bold transform group-hover/btn:scale-105 transition-all duration-300 flex items-center gap-3 hover:shadow-xl hover:shadow-purple-500/25">
                      <span>Explore creators</span>
                      <RocketLaunchIcon className="w-5 h-5" />
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
} 