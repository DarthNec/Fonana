#!/bin/bash

echo "🧹 Очистка кеша Fonana..."

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}✅ $1${NC}"
}

info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# 1. Остановить Next.js сервер
info "Остановка Next.js сервера..."
pkill -f "next-server" 2>/dev/null || true
pkill -f "node.*server.js" 2>/dev/null || true

# 2. Очистить build директорию
info "Очистка .next директории..."
rm -rf .next

# 3. Пересобрать приложение
info "Пересборка приложения..."
npm run build

if [ $? -eq 0 ]; then
    log "Сборка завершена успешно"
else
    echo "❌ Ошибка при сборке"
    exit 1
fi

# 4. Запустить сервер в фоне
info "Запуск Next.js сервера..."
export DATABASE_URL="file:./prisma/dev.db"
export NODE_ENV=production
export PORT=3001

nohup npm start > /dev/null 2>&1 &

# Подождать запуска
sleep 5

# 5. Проверить что сервер запустился
if ss -tlnp | grep 3001 > /dev/null; then
    log "Next.js сервер запущен на порту 3001"
else
    echo "❌ Не удалось запустить сервер"
    exit 1
fi

# 6. Проверить статические файлы
info "Проверка статических файлов..."
CSS_FILE=$(ls .next/static/css/*.css 2>/dev/null | head -1 | xargs basename)
JS_FILE=$(ls .next/static/chunks/webpack-*.js 2>/dev/null | head -1 | xargs basename)

if [ ! -z "$CSS_FILE" ]; then
    log "CSS файл: $CSS_FILE"
    echo "   Проверить: https://fonana.me/_next/static/css/$CSS_FILE"
fi

if [ ! -z "$JS_FILE" ]; then
    log "Webpack файл: $JS_FILE"
    echo "   Проверить: https://fonana.me/_next/static/chunks/$JS_FILE"
fi

# 7. Инструкции для пользователя
echo ""
echo "🎉 Кеш очищен и приложение перезапущено!"
echo ""
echo "📋 Инструкции для пользователей:"
echo "1. Откройте https://fonana.me"
echo "2. Нажмите Ctrl+F5 (Windows) или Cmd+Shift+R (Mac) для принудительного обновления"
echo "3. Или используйте режим инкогнито для проверки"
echo ""
echo "🔧 Полезные команды:"
echo "• Логи сервера: journalctl -u fonana -f"
echo "• Статус nginx: systemctl status nginx"
echo "• Перезапуск nginx: systemctl reload nginx" 